"""Export the accepted, reviewed SVG and routing receipt into a versioned geometry contract."""
from pathlib import Path
import json,re,hashlib,xml.etree.ElementTree as E
P=Path(__file__).resolve().parent;S=P.parent/'edge-variants';N='{http://www.w3.org/2000/svg}'
def ast(e):return {'tag':e.tag,'attributes':dict(e.attrib),'text':e.text,'children':[ast(c) for c in e]}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def port(p,b):
 x,y=p;x0,y0,x1,y1=b
 face='left' if x==x0 else 'right' if x==x1 else 'top' if y==y0 else 'bottom' if y==y1 else 'invalid'
 return {'position':p,'face':face}
r=E.parse(S/'custom-columns-final.svg').getroot();g=r.find(N+'g');
frame=g.find(N+'g[@id="domains-and-lanes"]');lastrect=None
for ix,child in enumerate(frame):
 if child.tag==N+'rect':lastrect=child.get('id')
 elif child.tag==N+'text':child.set('id','heading-'+(lastrect if lastrect else str(ix)));lastrect=None
routes=json.loads((S/'custom-columns-routing-routes.json').read_text());a=json.loads((S/'custom-columns-final-association.json').read_text());ops=json.loads(Path('/workspace/shared/uif-platform-endstate-20261030/canonical-graph-evidence.json').read_text())
contract={'schema':'offmenu.hld.layout','version':'2.1.0','coordinate_system':{'units':'SVG user units','x':'right','y':'down','graph_to_canvas_transform':g.get('transform'),'all_geometry':'graph-local unless explicitly root/canvas'},'canvas':{'attributes':dict(r.attrib),'viewBox':list(map(float,r.get('viewBox').split())),'margin_units':75,'background':'#ffffff','png_mode':'RGB'},'provenance':{'accepted_svg_sha256':sha(S/'custom-columns-final.svg'),'routing_receipt_sha256':sha(S/'custom-columns-routing-routes.json'),'semantic_topology_sha256':sha(S/'current-topology.dot'),'semantic_topology_warning':'DOT supplies semantic edge IDs/protocols only. Its old coordinates/styles are NOT the authoritative layout.','evidence_source_sha256':sha(Path('/workspace/shared/uif-platform-endstate-20261030/canonical-graph-evidence.json')),'restoration_baseline_sha256':sha(S/'offmenu-face-first-editable.zip'),'restoration_transform':'x_new=2530-x_old; y_new=1350-y_old. Node text is translated upright; headings stay above reversed columns.','post_transform_refinements':['Integration Delivery direct center ports','Runner Delivery outer-left corridor'],'operation_evidence':ops},'root_support':[ast(e)for e in r if e is not g],'graph_attributes':dict(g.attrib),'nodes':[],'edges':[],'labels':[],'groups':[],'z_order':[]}
for i,e in enumerate(g):
 cl=e.get('class');ident=e.get('id',f'graph-child-{i}')
 if cl=='node':
  key=e.find(N+'title').text;b=routes['node_bounds'][key];role={'linear':'work-management','github':'source-review-evidence','windmill':'execution','stokowski':'orchestration','langgraph':'workflow-recovery'}.get(key,'support')
  item={'id':key,'svg_id':ident,'box':b,'reference_box':b,'role':role,'functional_column':round(b[0]/560),'logical_group':'coordination-access' if key=='provider' else 'cloud-control' if key in ['durable','threads'] else 'compute-execution' if key in ['isolated','code','runner'] else 'main-platform','content':[{'text':t.text,'attributes':dict(t.attrib)}for t in e.findall(N+'text')],'style':dict(e.find(N+'path').attrib),'shadow':{'filter':'node-shadow','gaussian_stddev':4,'offset':[0,5],'opacity':0.32,'practical_clearance_units':20,'three_sigma_visual_extent':[-12,-7,12,17],'extent_definition':'Gaussian technically unbounded;3sigma bounds plus20unitclearance policy recorded explicitly'},'element':ast(e)}
  contract['nodes'].append(item);kind='node'
 elif cl=='edge':
  key=e.find(N+'title').text;src,dst=key.split('->');paths=e.findall(N+'path');path=[p for p in paths if p.get('stroke')!='#fafbfc'][-1];arr=e.findall(N+'polygon');route=routes['routes'][key]
  item={'id':key,'svg_id':ident,'source':src,'target':dst,'direction':'bidirectional' if len(arr)==2 else 'forward','source_port':port(route[0],routes['node_bounds'][src]),'target_port':port(route[-1],routes['node_bounds'][dst]),'polyline':route,'path_commands':[{'command':cmd,'coordinates':list(map(float,re.findall(r'-?\d+(?:\.\d+)?',coords)))}for cmd,coords in re.findall(r'([MLQCZ])([^MLQCZ]*)',path.get('d'))],'style':dict(path.attrib),'arrows':[dict(p.attrib)for p in arr],'protocol':a['labels'].get(key,{}).get('label',''),'operation_mapping_ids':next((rel.get('operation_mapping_ids',[])for rel in ops['relations']if rel['from']==src and rel['to']==dst),[]),'element':ast(e)}
  contract['edges'].append(item);kind='edge'
 elif ident=='protocol-labels':
  for le in e:
   key=le.get('data-edge');meta=a['labels'][key];item={'id':key,'edge_id':key,'text':meta['label'],'lines':meta['lines'],'center':meta['center'],'bbox':meta['bbox'],'segment_index':meta['segment_index'],'own_segment':meta['segment'],'rotation_degrees':0,'text_anchor':'middle','font_family':'DejaVu Sans','font_size':11,'background':dict(le.find(N+'rect').attrib),'text_elements':[dict(t.attrib)|{'text':t.text}for t in le.findall(N+'text')],'element':ast(le)};contract['labels'].append(item)
  item={'id':ident,'element':ast(e)};kind='labels'
 else:item={'id':ident,'element':ast(e)};contract['groups'].append(item);kind='group'
 contract['z_order'].append({'kind':kind,'id':key if cl in ['node','edge'] else ident})
from PIL import ImageFont
contract['containers']=[];contract['headings']=[]
for el in frame:
 if el.tag==N+'rect':
  x,y,w,h=map(float,[el.get(k)for k in ['x','y','width','height']]);box=[x,y,x+w,y+h];members=[n['id']for n in contract['nodes']if box[0]<=n['box'][0]and box[1]<=n['box'][1]and box[2]>=n['box'][2]and box[3]>=n['box'][3]];contract['containers'].append({'id':el.get('id'),'bounds':box,'style':dict(el.attrib),'members':members})
 elif el.tag==N+'text':
  text=el.text or '';size=int(float(el.get('font-size')));bold=el.get('font-weight')in['600','700','bold'];font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans'+('-Bold'if bold else'')+'.ttf',size);x,y=float(el.get('x')),float(el.get('y'));bb=font.getbbox(text,anchor='ls');shift=-font.getlength(text)/2 if el.get('text-anchor')=='middle'else 0
  contract['headings'].append({'id':el.get('id'),'text':text,'attributes':dict(el.attrib),'glyph_bbox':[x+shift+bb[0],y+bb[1],x+shift+bb[2],y+bb[3]],'font_file':'DejaVuSans'+('-Bold'if bold else'')+'.ttf'})
for node in contract['nodes']:node['container_ids']=[c['id']for c in contract['containers']if node['id']in c['members']]
contract['corridors']=[]
for lo,hi in [(290,560),(850,1120),(1410,1680),(1970,2240)]:
 tracks=sorted(set(a[0]for edge in contract['edges']for a,b in zip(edge['polyline'],edge['polyline'][1:])if a[0]==b[0]and lo<a[0]<hi and abs(a[1]-b[1])>=100))
 contract['corridors'].append({'axis':'vertical','gap_bounds':[lo,hi],'long_track_positions':tracks,'left_margin':tracks[0]-lo if tracks else None,'right_margin':hi-tracks[-1]if tracks else None,'pitch':[b-a for a,b in zip(tracks,tracks[1:])],'centering_is_soft_objective':True,'note':'Tracks occupy different Y intervals; aggregated positions are descriptive, not proof all are concurrent neighbors.'})
contract['functional_layout_note']='Compute is the top row; whole columns and their vertical contents reverse the18c03baseline; Workflow column runs Runner/blank/Journal/Delivery/SQLite/LangGraph atleft. Containers describe functional composition, not inferred physical hosting or shared ownership.'
contract['invariants']={'node_count':24,'relationship_count':44,'arrow_count':49,'protocol_label_count':43,'top_order':['runner','code','isolated'],'legend_present':False,'column_separator_count':0}
(P/'layout.json').write_text(json.dumps(contract,indent=2)+'\n');print('Exported layout.json')
