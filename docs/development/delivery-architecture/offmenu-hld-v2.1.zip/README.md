# OffMenu HLD coordinate contract, version 2.1.0

This is a portable code/JSON/SVG bundle, not an application. `layout.json` is the authoritative accepted geometry. Its IDs map to the existing 24 components,44 relationships,49 arrowheads and43 nonempty protocol labels; operation mapping IDs preserve the supplied evidence annotation without claiming target integrations are all deployed.

## Reproduce

Requirements: Python3.10+, numpy, svgpathtools; Inkscape and Pillow for PNG. Font: DejaVu Sans. Exact raster identity also depends on the recorded Inkscape/font environment.

    python validate_contract.py layout.json > validation.json
    python render_contract.py layout.json rebuilt.svg --png rebuilt.png

No network, credentials, models or graph-layout engine are used by these commands. Original reviewed output and independent review receipts accompany the bundle. The accepted export round-trip was pixel-identical at the dimensions recorded in `roundtrip.json`.

## Coordinate and edit rules

* All node, edge, port, label and group geometry uses SVG user units, origin upper-left, Ydown; the graph-to-canvas translation, root viewBox and pixel dimensions are explicit.75-user-unit canvas padding is retained. Do not mistake PNGpixels for graph units.
* `nodes[].box` is authoritative placement; `reference_box` anchors the node's serialized path/text. Translation is applied deterministically. Resizing is rejected until its path/text geometry is deliberately updated. `content` and `style` are editable. Node-only shadows are retained; practical20-unit exclusion clearance is recorded.
* `edges[].source/target`, `direction`, `operation_mapping_ids` and `protocol` are semantic. `source_port`/`target_port` and `polyline` are geometric assertions; the **actual rendered edge** is `path_commands` (M/L/Q with rounded corners and crossing bridges). Arrow polygons are explicit. Changing a route requires updating those synchronized fields together; validation rejects attachment mismatches. The renderer does not silently reroute.
* `labels[].center`, `background`, `text_elements` control rendering. `bbox`, `own_segment`, `segment_index` and protocol text are assertions requiring synchronized updates. All43 labels are unrotated, center-anchored and inline with their own relationship; no leader lines.
* `groups[].element` retains exact container rectangles, headings and styles. `z_order` controls stacking. `containers[].bounds/style` and `headings[].attributes/text` override those primitives; glyph boxes are explicit validation metadata. Root support includes the explicit white background and SVG shadow filter. There are no vertical column separator rules or legend.
* `element` stores exact SVG primitives to preserve unmodeled formatting. Explicit fields above override the corresponding primitives. It is not a substitute for the modeled geometry.
* `canvas.attributes` stores output sizing; `canvas.viewBox` supplies the root viewBox. If changing canvas extents, update its white background primitive too.

The old DOT file is **semantic reference only**: its obsolete coordinates and styles must not drive rendering. `export_contract.py` is the optional exporter tied to the source workspace; portable consumers need only JSON, renderer and validator.

## Verification and limits

The validator checks counts, stable IDs, directionality, ports, actual curve endpoints, orthogonality, node intrusions, shared segments, false endpoint junctions, own-edge labels, other-curve collisions, node/shadow and label separation, plus named user placement/face constraints. Source hashes, exact control points and provenance are retained. Independent review adds container/headerglyph clearance and visual legibility. This is not a claim of a globally optimal graph; one finite support-order alternative was tested and rejected after actual routing regressed crossings and face constraints.

Version2.1 restores the exact18c03column geometry and reorients the semantic layout, rather than mirroring raster text: Runner top-left, Application code and Coding workers to its right; blank left row, Journal then Delivery below; LangGraph bottom-left. Engineering contains exactly Provider, Review and PR. Node moves require corresponding port, route, control-point and label updates plus validation; no box edit automatically reroutes edges.

Restoration2.1: the immutable face-first baseline is transformed by x_new=2530−x_old and y_new=1350−y_old. Boxes and route points transform, but node text remains upright. Headings are reversed left-to-right and remain above all columns. Two small face refinements retain the requested direct Integration→Delivery CLI and outer-left Runner→Delivery corridor; all24/44 identities and49arrow directions remain intact.
